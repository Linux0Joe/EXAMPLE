import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Navbar from "./components/Navbar"
import Home from "./pages/Home"
import Community from "./pages/Community"
import Starfield from "./components/Starfield"
import PageTransition from "./components/PageTransition"

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white">
        <Starfield />
        <Navbar />
        <PageTransition>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/community" element={<Community />} />
          </Routes>
        </PageTransition>
      </div>
    </Router>
  )
}

export default App

