"use client"

import type React from "react"
import { useEffect, useRef } from "react"

interface ParallaxSectionProps {
  children: React.ReactNode
}

export const ParallaxSection: React.FC<ParallaxSectionProps> = ({ children }) => {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const scrollPosition = window.pageYOffset
        sectionRef.current.style.transform = `translateY(${scrollPosition * 0.3}px)`
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <div ref={sectionRef} className="relative">
      {children}
    </div>
  )
}

