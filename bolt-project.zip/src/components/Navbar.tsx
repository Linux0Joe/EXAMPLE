import type React from "react"
import { Link } from "react-router-dom"

const Navbar: React.FC = () => {
  const scrollToAbout = () => {
    const aboutSection = document.getElementById("about-section")
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold text-yellow-400">
            TimeWe
          </Link>
          <ul className="flex space-x-6">
            <li>
              <Link to="/" className="hover:text-yellow-400 transition-colors">
                Home
              </Link>
            </li>
            <li>
              <button onClick={scrollToAbout} className="hover:text-yellow-400 transition-colors">
                About
              </button>
            </li>
            <li>
              <Link to="/community" className="hover:text-yellow-400 transition-colors">
                Community
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Navbar

