import { motion } from "framer-motion"
import ParallaxSection from "../components/ParallaxSection"

function Community() {
  return (
    <div className="pt-20">
      <ParallaxSection className="max-w-4xl mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-purple-600"
        >
          Community
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-center text-gray-300 mb-12"
        >
          Join our vibrant community of innovators and visionaries shaping the future of decentralized finance.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 backdrop-blur-sm border border-purple-500/20 rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 text-yellow-400">Upcoming Events</h2>
            <ul className="space-y-4">
              <li className="text-gray-300">
                <span className="font-bold">Community AMA</span> - Every Friday at 3 PM UTC
              </li>
              <li className="text-gray-300">
                <span className="font-bold">Developer Workshops</span> - First Monday of each month
              </li>
              <li className="text-gray-300">
                <span className="font-bold">Quarterly Town Hall</span> - Next event on July 1st
              </li>
            </ul>
          </div>
          <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 backdrop-blur-sm border border-purple-500/20 rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 text-yellow-400">Get Involved</h2>
            <p className="text-gray-300 mb-4">
              There are many ways to contribute to the TimeWe ecosystem. Whether you're a developer, designer, or
              community enthusiast, your skills are valuable!
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black font-bold py-2 px-4 rounded-full hover:opacity-90 transition-opacity"
            >
              Join Our Discord
            </motion.button>
          </div>
        </motion.div>
      </ParallaxSection>
    </div>
  )
}

export default Community

