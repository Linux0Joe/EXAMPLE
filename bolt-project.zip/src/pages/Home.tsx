"use client"

import type React from "react"
import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { Clock, Users, Coins, MessageCircle, ArrowRight, Globe, Brain, Shield, Sparkles } from "lucide-react"
import ParallaxSection from "../components/ParallaxSection"
import TabSystem from "../components/TabSystem"
import SocialIcon from "../components/SocialIcon"

function Home() {
  const [activeTab, setActiveTab] = useState("welcome")
  const aboutRef = useRef<HTMLDivElement>(null)

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/50 to-blue-900/50" />
          <img
            src="https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=2048&q=80"
            alt="Galaxy background"
            className="w-full h-full object-cover"
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center px-4 max-w-4xl mx-auto"
        >
          <div className="animate-pulse mb-6">
            <Clock className="w-20 h-20 mx-auto text-yellow-400" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-purple-600">
            TimeWe
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            Uniting Intellectuals & Innovators to Advance the Solana Space
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black font-bold py-3 px-8 rounded-full hover:opacity-90 transition-opacity"
            onClick={() => scrollToSection(aboutRef)}
          >
            Learn More
          </motion.button>
        </motion.div>
      </div>

      {/* About Section */}
      <div id="about-section" ref={aboutRef} className="py-20">
        <ParallaxSection className="max-w-6xl mx-auto px-4">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl font-bold mb-12 text-center bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-purple-600"
          >
            About TimeWe
          </motion.h2>

          <TabSystem
            tabs={[
              {
                id: "welcome",
                label: "Welcome",
                content: <WelcomeSection />,
              },
              {
                id: "community",
                label: "Community",
                content: <CommunitySection />,
              },
              {
                id: "investment",
                label: "Investment",
                content: <InvestmentSection />,
              },
              {
                id: "technology",
                label: "Technology",
                content: <TechnologySection />,
              },
            ]}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        </ParallaxSection>
      </div>

      {/* Call to Action Section */}
      <ParallaxSection className="py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center py-20 px-4 rounded-3xl bg-gradient-to-r from-purple-900/30 to-blue-900/30 backdrop-blur-sm border border-purple-500/20 max-w-4xl mx-auto"
        >
          <Sparkles className="w-16 h-16 mx-auto text-yellow-400 mb-6" />
          <h2 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-purple-600">
            Join the TimeWe Revolution
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
            Be part of a community that's shaping the future of decentralized finance. Together, we can build something
            extraordinary.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black font-bold py-4 px-8 rounded-full hover:opacity-90 transition-opacity"
          >
            Start Your Journey
          </motion.button>
        </motion.div>
      </ParallaxSection>

      {/* Social Icons */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-4">
        <SocialIcon icon={<span className="text-xl font-bold">𝕏</span>} label="Follow on X" href="#" />
        <SocialIcon icon={<MessageCircle />} label="Join Telegram" href="#" />
      </div>
    </div>
  )
}

function WelcomeSection() {
  return (
    <Section
      icon={<Globe className="w-12 h-12" />}
      title="Welcome to the Future of DeFi"
      subtitle="Community-Driven Innovation Platform"
      description="TimeWe represents a paradigm shift in decentralized collaboration, combining cutting-edge technology with community governance. We're building more than just a token - we're creating an ecosystem where innovators, developers, and visionaries unite to shape the future of Solana."
      features={[
        "Decentralized Governance Structure",
        "Advanced Smart Contract Integration",
        "Cross-Chain Compatibility",
        "Real-Time Community Engagement",
      ]}
      imageSrc="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=2048&q=80"
      imageAlt="Futuristic city visualization"
    />
  )
}

function CommunitySection() {
  return (
    <Section
      icon={<Users className="w-12 h-12" />}
      title="Community Engagement"
      subtitle="Building Together, Growing Together"
      description="Our vibrant community is the cornerstone of TimeWe's success. Through innovative governance mechanisms and collaborative tools, we ensure every voice is heard and every contribution matters."
      features={[
        "Democratic Decision-Making Process",
        "Contributor Rewards System",
        "Regular Community Events",
        "Educational Resources & Workshops",
      ]}
      imageSrc="https://images.unsplash.com/photo-1552664730-d307ca884978?w=2048&q=80"
      imageAlt="Community collaboration"
      reverse
    />
  )
}

function InvestmentSection() {
  return (
    <Section
      icon={<Coins className="w-12 h-12" />}
      title="Investment & Tokenomics"
      subtitle="Sustainable Growth Through Innovation"
      description="TimeWe's economic model is designed for long-term sustainability and growth. Our tokenomics ensure fair distribution, reward active participation, and maintain economic stability."
      features={[
        "Transparent Token Distribution",
        "Staking Rewards Program",
        "Liquidity Mining Opportunities",
        "Community Treasury Management",
      ]}
      imageSrc="https://images.unsplash.com/photo-1605792657660-596af9009e82?w=2048&q=80"
      imageAlt="Digital finance visualization"
    />
  )
}

function TechnologySection() {
  return (
    <Section
      icon={<Brain className="w-12 h-12" />}
      title="AI & Quantum Integration"
      subtitle="Pushing the Boundaries of Technology"
      description="At the intersection of blockchain and advanced computing, TimeWe leverages cutting-edge AI and quantum-inspired algorithms to optimize platform performance and enhance user experience."
      features={[
        "AI-Powered Market Analysis",
        "Quantum-Resistant Security",
        "Automated Smart Contract Auditing",
        "Predictive Analytics Dashboard",
      ]}
      imageSrc="https://images.unsplash.com/photo-1677442136019-21780ecad995?w=2048&q=80"
      imageAlt="AI visualization"
      reverse
    />
  )
}

interface SectionProps {
  icon: React.ReactNode
  title: string
  subtitle: string
  description: string
  features: string[]
  imageSrc: string
  imageAlt: string
  reverse?: boolean
}

function Section({ icon, title, subtitle, description, features, imageSrc, imageAlt, reverse = false }: SectionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className={`flex flex-col ${reverse ? "md:flex-row-reverse" : "md:flex-row"} gap-12 items-center`}
    >
      <div className="flex-1 space-y-6">
        <div className="text-yellow-400 mb-4">{icon}</div>
        <h2 className="text-3xl font-bold">{title}</h2>
        <p className="text-xl text-purple-400">{subtitle}</p>
        <p className="text-gray-300">{description}</p>
        <ul className="space-y-4">
          {features.map((feature, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center space-x-2 text-gray-300"
            >
              <Shield className="w-5 h-5 text-yellow-400" />
              <span>{feature}</span>
            </motion.li>
          ))}
        </ul>
        <motion.button
          whileHover={{ x: 10 }}
          className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300 transition-colors"
        >
          <span>Learn More</span>
          <ArrowRight className="w-4 h-4" />
        </motion.button>
      </div>
      <motion.div whileHover={{ scale: 1.05 }} className="flex-1">
        <img
          src={imageSrc || "/placeholder.svg"}
          alt={imageAlt}
          className="rounded-xl shadow-2xl shadow-purple-500/20 w-full h-[400px] object-cover"
        />
      </motion.div>
    </motion.div>
  )
}

export default Home

