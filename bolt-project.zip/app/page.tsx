"use client"

import  from "../src/components/animations/Starfield"

export default function SyntheticV0PageForDeployment() {
  return < />
}